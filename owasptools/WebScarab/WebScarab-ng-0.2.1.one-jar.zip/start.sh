#!/bin/bash
java -jar WebScarab-ng-0.2.1.one-jar.jar